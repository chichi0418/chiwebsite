-- <!-- 112550081 許秉棋 第5次作業 12/6
-- 112550081 PING CHI HSU The Fifth Homework 12/6 -->
-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- 主機： localhost:8890
-- 產生時間： 2024-12-03 09:19:58
-- 伺服器版本： 5.7.24
-- PHP 版本： 8.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫: `blackjack_game`
--

-- --------------------------------------------------------

--
-- 資料表結構 `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `chips` int(11) DEFAULT '100',
  `game_data` text,
  `rounds` int(11) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `chips`, `game_data`, `rounds`, `created_at`) VALUES
(1, '0000', '$2y$10$I/Rh82Y5fZf2u5BaX1/9luuyYmsfXae1/r4SoJVj9WtrumyAvGFOe', 57, '{\"gameHistory\":[{\"playerHand\":\"[{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"3\\\"},{\\\"suit\\\":\\\"hearts\\\",\\\"value\\\":\\\"2\\\"},{\\\"suit\\\":\\\"hearts\\\",\\\"value\\\":\\\"ace\\\"},{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"jack\\\"}]\",\"dealerHand\":\"[{\\\"suit\\\":\\\"spades\\\",\\\"value\\\":\\\"10\\\"},{\\\"suit\\\":\\\"spades\\\",\\\"value\\\":\\\"8\\\"}]\",\"result\":\"You lose. (-1)\",\"bet\":1,\"remainingChips\":60,\"timestamp\":\"2024-12-03T09:12:06.497Z\"},{\"playerHand\":\"[{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"queen\\\"},{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"3\\\"},{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"6\\\"}]\",\"dealerHand\":\"[{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"9\\\"},{\\\"suit\\\":\\\"clubs\\\",\\\"value\\\":\\\"ace\\\"}]\",\"result\":\"You lose. (-1)\",\"bet\":1,\"remainingChips\":59,\"timestamp\":\"2024-12-03T09:12:11.924Z\"},{\"playerHand\":\"[{\\\"suit\\\":\\\"spades\\\",\\\"value\\\":\\\"2\\\"},{\\\"suit\\\":\\\"clubs\\\",\\\"value\\\":\\\"3\\\"},{\\\"suit\\\":\\\"hearts\\\",\\\"value\\\":\\\"5\\\"},{\\\"suit\\\":\\\"clubs\\\",\\\"value\\\":\\\"5\\\"},{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"8\\\"}]\",\"dealerHand\":\"[{\\\"suit\\\":\\\"spades\\\",\\\"value\\\":\\\"jack\\\"},{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"4\\\"}]\",\"result\":\"Bust! You lose. (-1)\",\"bet\":1,\"remainingChips\":58,\"timestamp\":\"2024-12-03T09:12:17.803Z\"},{\"playerHand\":\"[{\\\"suit\\\":\\\"hearts\\\",\\\"value\\\":\\\"king\\\"},{\\\"suit\\\":\\\"hearts\\\",\\\"value\\\":\\\"10\\\"}]\",\"dealerHand\":\"[{\\\"suit\\\":\\\"clubs\\\",\\\"value\\\":\\\"9\\\"},{\\\"suit\\\":\\\"clubs\\\",\\\"value\\\":\\\"queen\\\"},{\\\"suit\\\":\\\"hearts\\\",\\\"value\\\":\\\"2\\\"}]\",\"result\":\"You lose. (-1)\",\"bet\":1,\"remainingChips\":57,\"timestamp\":\"2024-12-03T09:12:29.358Z\"}]}', 0, '2024-11-27 09:22:09'),
(2, '1234', '$2y$10$UKN6YISIRHKRtjXrFKITPupHfgI0TDT59wWH2b1/Ol8fA3nyjdfeC', 5, '{\"gameHistory\":[]}', 0, '2024-11-28 05:56:03'),
(3, '3333', '$2y$10$vSTuJ5R.lhjbptMxHICXSO82c4ZJuy1I79.HV7DoDkNkFT2zU.qYa', 67, '{\"gameHistory\":[{\"playerHand\":\"[{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"3\\\"},{\\\"suit\\\":\\\"spades\\\",\\\"value\\\":\\\"jack\\\"},{\\\"suit\\\":\\\"clubs\\\",\\\"value\\\":\\\"9\\\"}]\",\"dealerHand\":\"[{\\\"suit\\\":\\\"spades\\\",\\\"value\\\":\\\"10\\\"},{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"8\\\"}]\",\"result\":\"Bust! You lose. (-27)\",\"bet\":27,\"remainingChips\":300},{\"playerHand\":\"[{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"king\\\"},{\\\"suit\\\":\\\"hearts\\\",\\\"value\\\":\\\"ace\\\"}]\",\"dealerHand\":\"[{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"2\\\"},{\\\"suit\\\":\\\"clubs\\\",\\\"value\\\":\\\"6\\\"}]\",\"result\":\"Blackjack! You win. (+52.5)\",\"bet\":35,\"remainingChips\":352.5},{\"playerHand\":\"[{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"8\\\"},{\\\"suit\\\":\\\"spades\\\",\\\"value\\\":\\\"9\\\"}]\",\"dealerHand\":\"[{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"4\\\"},{\\\"suit\\\":\\\"spades\\\",\\\"value\\\":\\\"5\\\"},{\\\"suit\\\":\\\"clubs\\\",\\\"value\\\":\\\"4\\\"},{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"jack\\\"}]\",\"result\":\"You win! (+99)\",\"bet\":99,\"remainingChips\":451.5},{\"playerHand\":\"[{\\\"suit\\\":\\\"spades\\\",\\\"value\\\":\\\"jack\\\"},{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"2\\\"},{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"7\\\"}]\",\"dealerHand\":\"[{\\\"suit\\\":\\\"spades\\\",\\\"value\\\":\\\"2\\\"},{\\\"suit\\\":\\\"hearts\\\",\\\"value\\\":\\\"10\\\"},{\\\"suit\\\":\\\"clubs\\\",\\\"value\\\":\\\"king\\\"}]\",\"result\":\"You win! (+17)\",\"bet\":17,\"remainingChips\":468},{\"playerHand\":\"[{\\\"suit\\\":\\\"clubs\\\",\\\"value\\\":\\\"3\\\"},{\\\"suit\\\":\\\"hearts\\\",\\\"value\\\":\\\"2\\\"},{\\\"suit\\\":\\\"spades\\\",\\\"value\\\":\\\"7\\\"}]\",\"dealerHand\":\"[{\\\"suit\\\":\\\"hearts\\\",\\\"value\\\":\\\"9\\\"},{\\\"suit\\\":\\\"hearts\\\",\\\"value\\\":\\\"6\\\"},{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"4\\\"}]\",\"result\":\"You lose. (-36)\",\"bet\":36,\"remainingChips\":432},{\"playerHand\":\"[{\\\"suit\\\":\\\"hearts\\\",\\\"value\\\":\\\"6\\\"},{\\\"suit\\\":\\\"spades\\\",\\\"value\\\":\\\"2\\\"},{\\\"suit\\\":\\\"hearts\\\",\\\"value\\\":\\\"ace\\\"}]\",\"dealerHand\":\"[{\\\"suit\\\":\\\"spades\\\",\\\"value\\\":\\\"ace\\\"},{\\\"suit\\\":\\\"clubs\\\",\\\"value\\\":\\\"2\\\"},{\\\"suit\\\":\\\"clubs\\\",\\\"value\\\":\\\"jack\\\"},{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"5\\\"}]\",\"result\":\"You win! (+55)\",\"bet\":55,\"remainingChips\":155},{\"playerHand\":\"[{\\\"suit\\\":\\\"spades\\\",\\\"value\\\":\\\"8\\\"},{\\\"suit\\\":\\\"clubs\\\",\\\"value\\\":\\\"10\\\"},{\\\"suit\\\":\\\"clubs\\\",\\\"value\\\":\\\"6\\\"}]\",\"dealerHand\":\"[{\\\"suit\\\":\\\"hearts\\\",\\\"value\\\":\\\"6\\\"},{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"2\\\"}]\",\"result\":\"Bust! You lose. (-5)\",\"bet\":5,\"remainingChips\":150},{\"playerHand\":\"[{\\\"suit\\\":\\\"spades\\\",\\\"value\\\":\\\"3\\\"},{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"10\\\"},{\\\"suit\\\":\\\"clubs\\\",\\\"value\\\":\\\"2\\\"},{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"2\\\"},{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"8\\\"}]\",\"dealerHand\":\"[{\\\"suit\\\":\\\"clubs\\\",\\\"value\\\":\\\"8\\\"},{\\\"suit\\\":\\\"hearts\\\",\\\"value\\\":\\\"7\\\"}]\",\"result\":\"Bust! You lose. (-15)\",\"bet\":15,\"remainingChips\":135},{\"playerHand\":\"[{\\\"suit\\\":\\\"clubs\\\",\\\"value\\\":\\\"8\\\"},{\\\"suit\\\":\\\"spades\\\",\\\"value\\\":\\\"7\\\"},{\\\"suit\\\":\\\"spades\\\",\\\"value\\\":\\\"king\\\"}]\",\"dealerHand\":\"[{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"4\\\"},{\\\"suit\\\":\\\"clubs\\\",\\\"value\\\":\\\"9\\\"}]\",\"result\":\"Bust! You lose. (-15)\",\"bet\":15,\"remainingChips\":120},{\"playerHand\":\"[{\\\"suit\\\":\\\"hearts\\\",\\\"value\\\":\\\"3\\\"},{\\\"suit\\\":\\\"hearts\\\",\\\"value\\\":\\\"4\\\"}]\",\"dealerHand\":\"[{\\\"suit\\\":\\\"hearts\\\",\\\"value\\\":\\\"queen\\\"},{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"3\\\"},{\\\"suit\\\":\\\"clubs\\\",\\\"value\\\":\\\"ace\\\"},{\\\"suit\\\":\\\"hearts\\\",\\\"value\\\":\\\"8\\\"}]\",\"result\":\"You win! (+1)\",\"bet\":1,\"remainingChips\":121},{\"playerHand\":\"[{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"8\\\"},{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"4\\\"}]\",\"dealerHand\":\"[{\\\"suit\\\":\\\"clubs\\\",\\\"value\\\":\\\"2\\\"},{\\\"suit\\\":\\\"spades\\\",\\\"value\\\":\\\"9\\\"}]\",\"result\":\"Dealer wins\",\"bet\":15,\"remainingChips\":91},{\"playerHand\":\"[{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"9\\\"},{\\\"suit\\\":\\\"hearts\\\",\\\"value\\\":\\\"5\\\"}]\",\"dealerHand\":\"[{\\\"suit\\\":\\\"hearts\\\",\\\"value\\\":\\\"jack\\\"},{\\\"suit\\\":\\\"spades\\\",\\\"value\\\":\\\"queen\\\"}]\",\"result\":\"You lose. (-16)\",\"bet\":16,\"remainingChips\":75},{\"playerHand\":\"[{\\\"suit\\\":\\\"spades\\\",\\\"value\\\":\\\"4\\\"},{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"king\\\"}]\",\"dealerHand\":\"[{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"4\\\"},{\\\"suit\\\":\\\"spades\\\",\\\"value\\\":\\\"ace\\\"},{\\\"suit\\\":\\\"clubs\\\",\\\"value\\\":\\\"ace\\\"},{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"9\\\"},{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"3\\\"}]\",\"result\":\"You lose. (-16)\",\"bet\":16,\"remainingChips\":59},{\"playerHand\":\"[{\\\"suit\\\":\\\"spades\\\",\\\"value\\\":\\\"queen\\\"},{\\\"suit\\\":\\\"hearts\\\",\\\"value\\\":\\\"king\\\"}]\",\"dealerHand\":\"[{\\\"suit\\\":\\\"diamonds\\\",\\\"value\\\":\\\"queen\\\"},{\\\"suit\\\":\\\"spades\\\",\\\"value\\\":\\\"9\\\"}]\",\"result\":\"You win! (+8)\",\"bet\":8,\"remainingChips\":67}]}', 0, '2024-12-01 13:43:41');

--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- 在傾印的資料表使用自動遞增(AUTO_INCREMENT)
--

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
